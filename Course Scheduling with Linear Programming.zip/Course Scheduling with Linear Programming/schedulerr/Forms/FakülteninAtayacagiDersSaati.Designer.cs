﻿namespace schedulerr.Forms
{
    partial class FakülteninAtayacagiDersSaati
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.c510 = new System.Windows.Forms.CheckBox();
            this.c410 = new System.Windows.Forms.CheckBox();
            this.c310 = new System.Windows.Forms.CheckBox();
            this.c210 = new System.Windows.Forms.CheckBox();
            this.c110 = new System.Windows.Forms.CheckBox();
            this.c59 = new System.Windows.Forms.CheckBox();
            this.c49 = new System.Windows.Forms.CheckBox();
            this.c39 = new System.Windows.Forms.CheckBox();
            this.c29 = new System.Windows.Forms.CheckBox();
            this.c19 = new System.Windows.Forms.CheckBox();
            this.c58 = new System.Windows.Forms.CheckBox();
            this.c48 = new System.Windows.Forms.CheckBox();
            this.c38 = new System.Windows.Forms.CheckBox();
            this.c28 = new System.Windows.Forms.CheckBox();
            this.c18 = new System.Windows.Forms.CheckBox();
            this.c57 = new System.Windows.Forms.CheckBox();
            this.c47 = new System.Windows.Forms.CheckBox();
            this.c37 = new System.Windows.Forms.CheckBox();
            this.c27 = new System.Windows.Forms.CheckBox();
            this.c17 = new System.Windows.Forms.CheckBox();
            this.c56 = new System.Windows.Forms.CheckBox();
            this.c46 = new System.Windows.Forms.CheckBox();
            this.c36 = new System.Windows.Forms.CheckBox();
            this.c26 = new System.Windows.Forms.CheckBox();
            this.c16 = new System.Windows.Forms.CheckBox();
            this.c55 = new System.Windows.Forms.CheckBox();
            this.c45 = new System.Windows.Forms.CheckBox();
            this.c35 = new System.Windows.Forms.CheckBox();
            this.c25 = new System.Windows.Forms.CheckBox();
            this.c15 = new System.Windows.Forms.CheckBox();
            this.c54 = new System.Windows.Forms.CheckBox();
            this.c44 = new System.Windows.Forms.CheckBox();
            this.c34 = new System.Windows.Forms.CheckBox();
            this.c24 = new System.Windows.Forms.CheckBox();
            this.c14 = new System.Windows.Forms.CheckBox();
            this.c53 = new System.Windows.Forms.CheckBox();
            this.c43 = new System.Windows.Forms.CheckBox();
            this.c33 = new System.Windows.Forms.CheckBox();
            this.c23 = new System.Windows.Forms.CheckBox();
            this.c13 = new System.Windows.Forms.CheckBox();
            this.c52 = new System.Windows.Forms.CheckBox();
            this.c42 = new System.Windows.Forms.CheckBox();
            this.c32 = new System.Windows.Forms.CheckBox();
            this.c22 = new System.Windows.Forms.CheckBox();
            this.c12 = new System.Windows.Forms.CheckBox();
            this.saatekleBTN = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.c51 = new System.Windows.Forms.CheckBox();
            this.c41 = new System.Windows.Forms.CheckBox();
            this.c31 = new System.Windows.Forms.CheckBox();
            this.c21 = new System.Windows.Forms.CheckBox();
            this.c11 = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dersatamaPANEL = new System.Windows.Forms.Panel();
            this.baslikLABEL = new System.Windows.Forms.Label();
            this.dersatamaPANEL.SuspendLayout();
            this.SuspendLayout();
            // 
            // c510
            // 
            this.c510.AutoSize = true;
            this.c510.Location = new System.Drawing.Point(759, 351);
            this.c510.Name = "c510";
            this.c510.Size = new System.Drawing.Size(15, 14);
            this.c510.TabIndex = 250;
            this.c510.UseVisualStyleBackColor = true;
            // 
            // c410
            // 
            this.c410.AutoSize = true;
            this.c410.Location = new System.Drawing.Point(627, 353);
            this.c410.Name = "c410";
            this.c410.Size = new System.Drawing.Size(15, 14);
            this.c410.TabIndex = 249;
            this.c410.UseVisualStyleBackColor = true;
            // 
            // c310
            // 
            this.c310.AutoSize = true;
            this.c310.Location = new System.Drawing.Point(488, 352);
            this.c310.Name = "c310";
            this.c310.Size = new System.Drawing.Size(15, 14);
            this.c310.TabIndex = 248;
            this.c310.UseVisualStyleBackColor = true;
            // 
            // c210
            // 
            this.c210.AutoSize = true;
            this.c210.Location = new System.Drawing.Point(356, 351);
            this.c210.Name = "c210";
            this.c210.Size = new System.Drawing.Size(15, 14);
            this.c210.TabIndex = 247;
            this.c210.UseVisualStyleBackColor = true;
            // 
            // c110
            // 
            this.c110.AutoSize = true;
            this.c110.Location = new System.Drawing.Point(226, 351);
            this.c110.Name = "c110";
            this.c110.Size = new System.Drawing.Size(15, 14);
            this.c110.TabIndex = 246;
            this.c110.UseVisualStyleBackColor = true;
            // 
            // c59
            // 
            this.c59.AutoSize = true;
            this.c59.Location = new System.Drawing.Point(759, 321);
            this.c59.Name = "c59";
            this.c59.Size = new System.Drawing.Size(15, 14);
            this.c59.TabIndex = 245;
            this.c59.UseVisualStyleBackColor = true;
            // 
            // c49
            // 
            this.c49.AutoSize = true;
            this.c49.Location = new System.Drawing.Point(627, 323);
            this.c49.Name = "c49";
            this.c49.Size = new System.Drawing.Size(15, 14);
            this.c49.TabIndex = 244;
            this.c49.UseVisualStyleBackColor = true;
            // 
            // c39
            // 
            this.c39.AutoSize = true;
            this.c39.Location = new System.Drawing.Point(488, 322);
            this.c39.Name = "c39";
            this.c39.Size = new System.Drawing.Size(15, 14);
            this.c39.TabIndex = 243;
            this.c39.UseVisualStyleBackColor = true;
            // 
            // c29
            // 
            this.c29.AutoSize = true;
            this.c29.Location = new System.Drawing.Point(356, 321);
            this.c29.Name = "c29";
            this.c29.Size = new System.Drawing.Size(15, 14);
            this.c29.TabIndex = 242;
            this.c29.UseVisualStyleBackColor = true;
            // 
            // c19
            // 
            this.c19.AutoSize = true;
            this.c19.Location = new System.Drawing.Point(226, 321);
            this.c19.Name = "c19";
            this.c19.Size = new System.Drawing.Size(15, 14);
            this.c19.TabIndex = 241;
            this.c19.UseVisualStyleBackColor = true;
            // 
            // c58
            // 
            this.c58.AutoSize = true;
            this.c58.Location = new System.Drawing.Point(759, 294);
            this.c58.Name = "c58";
            this.c58.Size = new System.Drawing.Size(15, 14);
            this.c58.TabIndex = 240;
            this.c58.UseVisualStyleBackColor = true;
            // 
            // c48
            // 
            this.c48.AutoSize = true;
            this.c48.Location = new System.Drawing.Point(627, 296);
            this.c48.Name = "c48";
            this.c48.Size = new System.Drawing.Size(15, 14);
            this.c48.TabIndex = 239;
            this.c48.UseVisualStyleBackColor = true;
            // 
            // c38
            // 
            this.c38.AutoSize = true;
            this.c38.Location = new System.Drawing.Point(488, 295);
            this.c38.Name = "c38";
            this.c38.Size = new System.Drawing.Size(15, 14);
            this.c38.TabIndex = 238;
            this.c38.UseVisualStyleBackColor = true;
            // 
            // c28
            // 
            this.c28.AutoSize = true;
            this.c28.Location = new System.Drawing.Point(356, 294);
            this.c28.Name = "c28";
            this.c28.Size = new System.Drawing.Size(15, 14);
            this.c28.TabIndex = 237;
            this.c28.UseVisualStyleBackColor = true;
            // 
            // c18
            // 
            this.c18.AutoSize = true;
            this.c18.Location = new System.Drawing.Point(226, 294);
            this.c18.Name = "c18";
            this.c18.Size = new System.Drawing.Size(15, 14);
            this.c18.TabIndex = 236;
            this.c18.UseVisualStyleBackColor = true;
            // 
            // c57
            // 
            this.c57.AutoSize = true;
            this.c57.Location = new System.Drawing.Point(759, 267);
            this.c57.Name = "c57";
            this.c57.Size = new System.Drawing.Size(15, 14);
            this.c57.TabIndex = 235;
            this.c57.UseVisualStyleBackColor = true;
            // 
            // c47
            // 
            this.c47.AutoSize = true;
            this.c47.Location = new System.Drawing.Point(627, 269);
            this.c47.Name = "c47";
            this.c47.Size = new System.Drawing.Size(15, 14);
            this.c47.TabIndex = 234;
            this.c47.UseVisualStyleBackColor = true;
            // 
            // c37
            // 
            this.c37.AutoSize = true;
            this.c37.Location = new System.Drawing.Point(488, 268);
            this.c37.Name = "c37";
            this.c37.Size = new System.Drawing.Size(15, 14);
            this.c37.TabIndex = 233;
            this.c37.UseVisualStyleBackColor = true;
            // 
            // c27
            // 
            this.c27.AutoSize = true;
            this.c27.Location = new System.Drawing.Point(356, 267);
            this.c27.Name = "c27";
            this.c27.Size = new System.Drawing.Size(15, 14);
            this.c27.TabIndex = 232;
            this.c27.UseVisualStyleBackColor = true;
            // 
            // c17
            // 
            this.c17.AutoSize = true;
            this.c17.Location = new System.Drawing.Point(226, 267);
            this.c17.Name = "c17";
            this.c17.Size = new System.Drawing.Size(15, 14);
            this.c17.TabIndex = 231;
            this.c17.UseVisualStyleBackColor = true;
            // 
            // c56
            // 
            this.c56.AutoSize = true;
            this.c56.Location = new System.Drawing.Point(759, 238);
            this.c56.Name = "c56";
            this.c56.Size = new System.Drawing.Size(15, 14);
            this.c56.TabIndex = 230;
            this.c56.UseVisualStyleBackColor = true;
            // 
            // c46
            // 
            this.c46.AutoSize = true;
            this.c46.Location = new System.Drawing.Point(627, 240);
            this.c46.Name = "c46";
            this.c46.Size = new System.Drawing.Size(15, 14);
            this.c46.TabIndex = 229;
            this.c46.UseVisualStyleBackColor = true;
            // 
            // c36
            // 
            this.c36.AutoSize = true;
            this.c36.Location = new System.Drawing.Point(488, 239);
            this.c36.Name = "c36";
            this.c36.Size = new System.Drawing.Size(15, 14);
            this.c36.TabIndex = 228;
            this.c36.UseVisualStyleBackColor = true;
            // 
            // c26
            // 
            this.c26.AutoSize = true;
            this.c26.Location = new System.Drawing.Point(356, 238);
            this.c26.Name = "c26";
            this.c26.Size = new System.Drawing.Size(15, 14);
            this.c26.TabIndex = 227;
            this.c26.UseVisualStyleBackColor = true;
            // 
            // c16
            // 
            this.c16.AutoSize = true;
            this.c16.Location = new System.Drawing.Point(226, 238);
            this.c16.Name = "c16";
            this.c16.Size = new System.Drawing.Size(15, 14);
            this.c16.TabIndex = 226;
            this.c16.UseVisualStyleBackColor = true;
            // 
            // c55
            // 
            this.c55.AutoSize = true;
            this.c55.Location = new System.Drawing.Point(759, 208);
            this.c55.Name = "c55";
            this.c55.Size = new System.Drawing.Size(15, 14);
            this.c55.TabIndex = 225;
            this.c55.UseVisualStyleBackColor = true;
            // 
            // c45
            // 
            this.c45.AutoSize = true;
            this.c45.Location = new System.Drawing.Point(627, 210);
            this.c45.Name = "c45";
            this.c45.Size = new System.Drawing.Size(15, 14);
            this.c45.TabIndex = 224;
            this.c45.UseVisualStyleBackColor = true;
            // 
            // c35
            // 
            this.c35.AutoSize = true;
            this.c35.Location = new System.Drawing.Point(488, 209);
            this.c35.Name = "c35";
            this.c35.Size = new System.Drawing.Size(15, 14);
            this.c35.TabIndex = 223;
            this.c35.UseVisualStyleBackColor = true;
            // 
            // c25
            // 
            this.c25.AutoSize = true;
            this.c25.Location = new System.Drawing.Point(356, 208);
            this.c25.Name = "c25";
            this.c25.Size = new System.Drawing.Size(15, 14);
            this.c25.TabIndex = 222;
            this.c25.UseVisualStyleBackColor = true;
            // 
            // c15
            // 
            this.c15.AutoSize = true;
            this.c15.Location = new System.Drawing.Point(226, 208);
            this.c15.Name = "c15";
            this.c15.Size = new System.Drawing.Size(15, 14);
            this.c15.TabIndex = 221;
            this.c15.UseVisualStyleBackColor = true;
            // 
            // c54
            // 
            this.c54.AutoSize = true;
            this.c54.Location = new System.Drawing.Point(759, 176);
            this.c54.Name = "c54";
            this.c54.Size = new System.Drawing.Size(15, 14);
            this.c54.TabIndex = 220;
            this.c54.UseVisualStyleBackColor = true;
            // 
            // c44
            // 
            this.c44.AutoSize = true;
            this.c44.Location = new System.Drawing.Point(627, 178);
            this.c44.Name = "c44";
            this.c44.Size = new System.Drawing.Size(15, 14);
            this.c44.TabIndex = 219;
            this.c44.UseVisualStyleBackColor = true;
            // 
            // c34
            // 
            this.c34.AutoSize = true;
            this.c34.Location = new System.Drawing.Point(488, 177);
            this.c34.Name = "c34";
            this.c34.Size = new System.Drawing.Size(15, 14);
            this.c34.TabIndex = 218;
            this.c34.UseVisualStyleBackColor = true;
            // 
            // c24
            // 
            this.c24.AutoSize = true;
            this.c24.Location = new System.Drawing.Point(356, 176);
            this.c24.Name = "c24";
            this.c24.Size = new System.Drawing.Size(15, 14);
            this.c24.TabIndex = 217;
            this.c24.UseVisualStyleBackColor = true;
            // 
            // c14
            // 
            this.c14.AutoSize = true;
            this.c14.Location = new System.Drawing.Point(226, 176);
            this.c14.Name = "c14";
            this.c14.Size = new System.Drawing.Size(15, 14);
            this.c14.TabIndex = 216;
            this.c14.UseVisualStyleBackColor = true;
            // 
            // c53
            // 
            this.c53.AutoSize = true;
            this.c53.Location = new System.Drawing.Point(759, 143);
            this.c53.Name = "c53";
            this.c53.Size = new System.Drawing.Size(15, 14);
            this.c53.TabIndex = 215;
            this.c53.UseVisualStyleBackColor = true;
            // 
            // c43
            // 
            this.c43.AutoSize = true;
            this.c43.Location = new System.Drawing.Point(627, 145);
            this.c43.Name = "c43";
            this.c43.Size = new System.Drawing.Size(15, 14);
            this.c43.TabIndex = 214;
            this.c43.UseVisualStyleBackColor = true;
            // 
            // c33
            // 
            this.c33.AutoSize = true;
            this.c33.Location = new System.Drawing.Point(488, 144);
            this.c33.Name = "c33";
            this.c33.Size = new System.Drawing.Size(15, 14);
            this.c33.TabIndex = 213;
            this.c33.UseVisualStyleBackColor = true;
            // 
            // c23
            // 
            this.c23.AutoSize = true;
            this.c23.Location = new System.Drawing.Point(356, 143);
            this.c23.Name = "c23";
            this.c23.Size = new System.Drawing.Size(15, 14);
            this.c23.TabIndex = 212;
            this.c23.UseVisualStyleBackColor = true;
            // 
            // c13
            // 
            this.c13.AutoSize = true;
            this.c13.Location = new System.Drawing.Point(226, 143);
            this.c13.Name = "c13";
            this.c13.Size = new System.Drawing.Size(15, 14);
            this.c13.TabIndex = 211;
            this.c13.UseVisualStyleBackColor = true;
            // 
            // c52
            // 
            this.c52.AutoSize = true;
            this.c52.Location = new System.Drawing.Point(759, 112);
            this.c52.Name = "c52";
            this.c52.Size = new System.Drawing.Size(15, 14);
            this.c52.TabIndex = 210;
            this.c52.UseVisualStyleBackColor = true;
            // 
            // c42
            // 
            this.c42.AutoSize = true;
            this.c42.Location = new System.Drawing.Point(627, 114);
            this.c42.Name = "c42";
            this.c42.Size = new System.Drawing.Size(15, 14);
            this.c42.TabIndex = 209;
            this.c42.UseVisualStyleBackColor = true;
            // 
            // c32
            // 
            this.c32.AutoSize = true;
            this.c32.Location = new System.Drawing.Point(488, 113);
            this.c32.Name = "c32";
            this.c32.Size = new System.Drawing.Size(15, 14);
            this.c32.TabIndex = 208;
            this.c32.UseVisualStyleBackColor = true;
            // 
            // c22
            // 
            this.c22.AutoSize = true;
            this.c22.Location = new System.Drawing.Point(356, 112);
            this.c22.Name = "c22";
            this.c22.Size = new System.Drawing.Size(15, 14);
            this.c22.TabIndex = 207;
            this.c22.UseVisualStyleBackColor = true;
            // 
            // c12
            // 
            this.c12.AutoSize = true;
            this.c12.Location = new System.Drawing.Point(226, 112);
            this.c12.Name = "c12";
            this.c12.Size = new System.Drawing.Size(15, 14);
            this.c12.TabIndex = 206;
            this.c12.UseVisualStyleBackColor = true;
            // 
            // saatekleBTN
            // 
            this.saatekleBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.saatekleBTN.Location = new System.Drawing.Point(357, 404);
            this.saatekleBTN.Name = "saatekleBTN";
            this.saatekleBTN.Size = new System.Drawing.Size(146, 32);
            this.saatekleBTN.TabIndex = 205;
            this.saatekleBTN.Text = "Kaydet";
            this.saatekleBTN.UseVisualStyleBackColor = true;
            this.saatekleBTN.Click += new System.EventHandler(this.saatekleBTN_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Maroon;
            this.label19.Location = new System.Drawing.Point(339, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(213, 13);
            this.label19.TabIndex = 204;
            this.label19.Text = "Dersin kesin olması gereken saatleri seçiniz.";
            // 
            // c51
            // 
            this.c51.AutoSize = true;
            this.c51.Location = new System.Drawing.Point(759, 81);
            this.c51.Name = "c51";
            this.c51.Size = new System.Drawing.Size(15, 14);
            this.c51.TabIndex = 158;
            this.c51.UseVisualStyleBackColor = true;
            // 
            // c41
            // 
            this.c41.AutoSize = true;
            this.c41.Location = new System.Drawing.Point(627, 83);
            this.c41.Name = "c41";
            this.c41.Size = new System.Drawing.Size(15, 14);
            this.c41.TabIndex = 157;
            this.c41.UseVisualStyleBackColor = true;
            // 
            // c31
            // 
            this.c31.AutoSize = true;
            this.c31.Location = new System.Drawing.Point(488, 82);
            this.c31.Name = "c31";
            this.c31.Size = new System.Drawing.Size(15, 14);
            this.c31.TabIndex = 156;
            this.c31.UseVisualStyleBackColor = true;
            // 
            // c21
            // 
            this.c21.AutoSize = true;
            this.c21.Location = new System.Drawing.Point(356, 81);
            this.c21.Name = "c21";
            this.c21.Size = new System.Drawing.Size(15, 14);
            this.c21.TabIndex = 155;
            this.c21.UseVisualStyleBackColor = true;
            // 
            // c11
            // 
            this.c11.AutoSize = true;
            this.c11.Location = new System.Drawing.Point(226, 81);
            this.c11.Name = "c11";
            this.c11.Size = new System.Drawing.Size(15, 14);
            this.c11.TabIndex = 154;
            this.c11.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(58, 348);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(87, 19);
            this.label18.TabIndex = 153;
            this.label18.Text = "16.30-17.15";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(58, 112);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 19);
            this.label17.TabIndex = 152;
            this.label17.Text = "9.10-9.55";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(58, 318);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(87, 19);
            this.label16.TabIndex = 151;
            this.label16.Text = "15.35-16.20";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(58, 290);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 19);
            this.label15.TabIndex = 150;
            this.label15.Text = "14.40-15.25";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(58, 264);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 19);
            this.label14.TabIndex = 149;
            this.label14.Text = "13.45-15.30";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(57, 235);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 19);
            this.label13.TabIndex = 148;
            this.label13.Text = "12.50-13.35";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(57, 205);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 19);
            this.label12.TabIndex = 147;
            this.label12.Text = "11.55-12-40";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(58, 173);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 19);
            this.label11.TabIndex = 146;
            this.label11.Text = "11.00-11.45";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(57, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 19);
            this.label10.TabIndex = 145;
            this.label10.Text = "10.05-10.50";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(58, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 19);
            this.label9.TabIndex = 144;
            this.label9.Text = "8.15-9.00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(198, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 25);
            this.label4.TabIndex = 139;
            this.label4.Text = "Pazartesi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(337, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 25);
            this.label5.TabIndex = 140;
            this.label5.Text = "Salı";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(447, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 25);
            this.label6.TabIndex = 141;
            this.label6.Text = "Çarşamba";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(585, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 25);
            this.label7.TabIndex = 142;
            this.label7.Text = "Perşembe";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(734, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 25);
            this.label8.TabIndex = 143;
            this.label8.Text = "Cuma";
            // 
            // dersatamaPANEL
            // 
            this.dersatamaPANEL.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dersatamaPANEL.Controls.Add(this.c510);
            this.dersatamaPANEL.Controls.Add(this.c410);
            this.dersatamaPANEL.Controls.Add(this.c310);
            this.dersatamaPANEL.Controls.Add(this.c210);
            this.dersatamaPANEL.Controls.Add(this.c110);
            this.dersatamaPANEL.Controls.Add(this.c59);
            this.dersatamaPANEL.Controls.Add(this.c49);
            this.dersatamaPANEL.Controls.Add(this.c39);
            this.dersatamaPANEL.Controls.Add(this.c29);
            this.dersatamaPANEL.Controls.Add(this.c19);
            this.dersatamaPANEL.Controls.Add(this.c58);
            this.dersatamaPANEL.Controls.Add(this.c48);
            this.dersatamaPANEL.Controls.Add(this.c38);
            this.dersatamaPANEL.Controls.Add(this.c28);
            this.dersatamaPANEL.Controls.Add(this.c18);
            this.dersatamaPANEL.Controls.Add(this.c57);
            this.dersatamaPANEL.Controls.Add(this.c47);
            this.dersatamaPANEL.Controls.Add(this.c37);
            this.dersatamaPANEL.Controls.Add(this.c27);
            this.dersatamaPANEL.Controls.Add(this.c17);
            this.dersatamaPANEL.Controls.Add(this.c56);
            this.dersatamaPANEL.Controls.Add(this.c46);
            this.dersatamaPANEL.Controls.Add(this.c36);
            this.dersatamaPANEL.Controls.Add(this.c26);
            this.dersatamaPANEL.Controls.Add(this.c16);
            this.dersatamaPANEL.Controls.Add(this.c55);
            this.dersatamaPANEL.Controls.Add(this.c45);
            this.dersatamaPANEL.Controls.Add(this.c35);
            this.dersatamaPANEL.Controls.Add(this.c25);
            this.dersatamaPANEL.Controls.Add(this.c15);
            this.dersatamaPANEL.Controls.Add(this.c54);
            this.dersatamaPANEL.Controls.Add(this.c44);
            this.dersatamaPANEL.Controls.Add(this.c34);
            this.dersatamaPANEL.Controls.Add(this.c24);
            this.dersatamaPANEL.Controls.Add(this.c14);
            this.dersatamaPANEL.Controls.Add(this.c53);
            this.dersatamaPANEL.Controls.Add(this.c43);
            this.dersatamaPANEL.Controls.Add(this.c33);
            this.dersatamaPANEL.Controls.Add(this.c23);
            this.dersatamaPANEL.Controls.Add(this.c13);
            this.dersatamaPANEL.Controls.Add(this.c52);
            this.dersatamaPANEL.Controls.Add(this.c42);
            this.dersatamaPANEL.Controls.Add(this.c32);
            this.dersatamaPANEL.Controls.Add(this.c22);
            this.dersatamaPANEL.Controls.Add(this.c12);
            this.dersatamaPANEL.Controls.Add(this.saatekleBTN);
            this.dersatamaPANEL.Controls.Add(this.label19);
            this.dersatamaPANEL.Controls.Add(this.c51);
            this.dersatamaPANEL.Controls.Add(this.c41);
            this.dersatamaPANEL.Controls.Add(this.c31);
            this.dersatamaPANEL.Controls.Add(this.c21);
            this.dersatamaPANEL.Controls.Add(this.c11);
            this.dersatamaPANEL.Controls.Add(this.label18);
            this.dersatamaPANEL.Controls.Add(this.label17);
            this.dersatamaPANEL.Controls.Add(this.label16);
            this.dersatamaPANEL.Controls.Add(this.label15);
            this.dersatamaPANEL.Controls.Add(this.label14);
            this.dersatamaPANEL.Controls.Add(this.label13);
            this.dersatamaPANEL.Controls.Add(this.label12);
            this.dersatamaPANEL.Controls.Add(this.label11);
            this.dersatamaPANEL.Controls.Add(this.label10);
            this.dersatamaPANEL.Controls.Add(this.label9);
            this.dersatamaPANEL.Controls.Add(this.label4);
            this.dersatamaPANEL.Controls.Add(this.label5);
            this.dersatamaPANEL.Controls.Add(this.label6);
            this.dersatamaPANEL.Controls.Add(this.label7);
            this.dersatamaPANEL.Controls.Add(this.label8);
            this.dersatamaPANEL.Location = new System.Drawing.Point(217, 98);
            this.dersatamaPANEL.Name = "dersatamaPANEL";
            this.dersatamaPANEL.Size = new System.Drawing.Size(862, 457);
            this.dersatamaPANEL.TabIndex = 5;
            // 
            // baslikLABEL
            // 
            this.baslikLABEL.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.baslikLABEL.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.baslikLABEL.ForeColor = System.Drawing.Color.White;
            this.baslikLABEL.Location = new System.Drawing.Point(12, 58);
            this.baslikLABEL.Name = "baslikLABEL";
            this.baslikLABEL.Size = new System.Drawing.Size(1274, 37);
            this.baslikLABEL.TabIndex = 0;
            this.baslikLABEL.Text = "z";
            this.baslikLABEL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.baslikLABEL.Click += new System.EventHandler(this.baslikLABEL_Click);
            // 
            // FakülteninAtayacagiDersSaati
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1298, 605);
            this.Controls.Add(this.dersatamaPANEL);
            this.Controls.Add(this.baslikLABEL);
            this.Name = "FakülteninAtayacagiDersSaati";
            this.Text = "FakülteninAtayacagiDersSaati";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.dersatamaPANEL.ResumeLayout(false);
            this.dersatamaPANEL.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox c510;
        private System.Windows.Forms.CheckBox c410;
        private System.Windows.Forms.CheckBox c310;
        private System.Windows.Forms.CheckBox c210;
        private System.Windows.Forms.CheckBox c110;
        private System.Windows.Forms.CheckBox c59;
        private System.Windows.Forms.CheckBox c49;
        private System.Windows.Forms.CheckBox c39;
        private System.Windows.Forms.CheckBox c29;
        private System.Windows.Forms.CheckBox c19;
        private System.Windows.Forms.CheckBox c58;
        private System.Windows.Forms.CheckBox c48;
        private System.Windows.Forms.CheckBox c38;
        private System.Windows.Forms.CheckBox c28;
        private System.Windows.Forms.CheckBox c18;
        private System.Windows.Forms.CheckBox c57;
        private System.Windows.Forms.CheckBox c47;
        private System.Windows.Forms.CheckBox c37;
        private System.Windows.Forms.CheckBox c27;
        private System.Windows.Forms.CheckBox c17;
        private System.Windows.Forms.CheckBox c56;
        private System.Windows.Forms.CheckBox c46;
        private System.Windows.Forms.CheckBox c36;
        private System.Windows.Forms.CheckBox c26;
        private System.Windows.Forms.CheckBox c16;
        private System.Windows.Forms.CheckBox c55;
        private System.Windows.Forms.CheckBox c45;
        private System.Windows.Forms.CheckBox c35;
        private System.Windows.Forms.CheckBox c25;
        private System.Windows.Forms.CheckBox c15;
        private System.Windows.Forms.CheckBox c54;
        private System.Windows.Forms.CheckBox c44;
        private System.Windows.Forms.CheckBox c34;
        private System.Windows.Forms.CheckBox c24;
        private System.Windows.Forms.CheckBox c14;
        private System.Windows.Forms.CheckBox c53;
        private System.Windows.Forms.CheckBox c43;
        private System.Windows.Forms.CheckBox c33;
        private System.Windows.Forms.CheckBox c23;
        private System.Windows.Forms.CheckBox c13;
        private System.Windows.Forms.CheckBox c52;
        private System.Windows.Forms.CheckBox c42;
        private System.Windows.Forms.CheckBox c32;
        private System.Windows.Forms.CheckBox c22;
        private System.Windows.Forms.CheckBox c12;
        private System.Windows.Forms.Button saatekleBTN;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox c51;
        private System.Windows.Forms.CheckBox c41;
        private System.Windows.Forms.CheckBox c31;
        private System.Windows.Forms.CheckBox c21;
        private System.Windows.Forms.CheckBox c11;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel dersatamaPANEL;
        private System.Windows.Forms.Label baslikLABEL;
    }
}